							--- Tests for Ex1 Wet ATAM winter 2023-2023 ---
Requirements to run:
- Run on Linux (wsl/linux vm/linux machine)
- Have python 3 (My version is Python 3.10.12) but maybe other versions could work too

* individual instructions about running each of the questions are in their destined directories